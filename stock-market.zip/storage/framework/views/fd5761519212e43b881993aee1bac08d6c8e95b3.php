<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Update Stock</div>
                    <div class="panel-body">
                        <!--begin::Form-->
                        <?php echo e(Html::ul($errors->all())); ?>

                        <?php echo e(Form::model($stock, array('route' => array('stocks.update', $stock->id), 'method' => 'PUT', 'class' => 'form-horizontal', 'id' => '"maskForm"'))); ?>


                        <div class="form-group<?php echo e($errors->has('type') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('type', 'Select type of Stock', array( 'class' => 'col-lg-3 col-form-label'))); ?>

                            <div class="col-lg-6">
                                <div class="m-radio-inline">
                                    <?php echo e(Form::select('type', array('NaN' => 'NaN', 'PREFERRED' => 'Preferred Stock', 'COMMON' => 'Common Stock'), Input::old('type'), array('class' => 'form-control m-input'))); ?>

                                </div>
                                <span class="m-form__help">Please select type of stock</span>
                            </div>

                        </div>

                        <div class="form-group<?php echo e($errors->has('_company_id') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('_company_id', 'Select Company of Stock', array( 'class' => 'col-lg-3 col-form-label'))); ?>

                            <div class="col-lg-6">
                                <div class="m-radio-inline">
                                    <select name="_company_id" id="_company_id" class="form-control m-input">
                                        <?php foreach(Auth::user()->companies as $company): ?>
                                            <option value="<?php echo e($company->id); ?>" <?php if($company->id === Input::old('_company_id')): ?> selected="selected" <?php endif; ?>><?php echo e($company->title); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('_market_id') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('_market_id', 'Select Market of Stock', array( 'class' => 'col-lg-3 col-form-label'))); ?>

                            <div class="col-lg-6">
                                <div class="m-radio-inline">
                                    <select name="_market_id" id="_market_id" class="form-control m-input">
                                        <?php foreach(Auth::user()->markets as $market): ?>
                                            <option value="<?php echo e($market->id); ?>" <?php if($market->id === Input::old('_market_id')): ?> selected="selected" <?php endif; ?>><?php echo e($market->title); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('price', 'Price', array( 'class' => 'col-lg-3 col-form-label'))); ?>

                            <div class="col-lg-6">
                                <?php echo e(Form::number('price', Input::old('price'), array('class' => 'form-control m-input', 'placeholder' => '00.00', 'required' => 'required', 'step'=>'0.001'))); ?>

                                <?php if($errors->has('title')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('price')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('description', 'Description', array('class' => 'col-lg-3 col-form-label'))); ?>


                            <div class="col-lg-6">
                                <?php echo e(Form::textarea('description', Input::old('description'), array('class' => 'form-control m-input', 'placeholder' => 'Enter your stock description'))); ?>

                                <?php if($errors->has('description')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <?php echo e(Form::submit('Update Stock!', array('class' => 'btn btn-success'))); ?>

                                <?php echo e(Form::reset('Reset!', array('class' => 'btn btn-secondary'))); ?>

                            </div>
                        </div>

                    <?php echo e(Form::close()); ?>

                    <!--end::Form-->

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>