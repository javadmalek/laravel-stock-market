<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Update Market</div>
                    <div class="panel-body">
                        <!--begin::Form-->
                        <?php echo e(Html::ul($errors->all())); ?>

                        <?php echo e(Form::model($market, array('route' => array('markets.update', $market->id), 'method' => 'PUT', 'class' => 'form-horizontal', 'id' => '"maskForm"'))); ?>


                        <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('title', 'Market Title', array('class' => 'col-lg-3 col-form-label'))); ?>


                            <div class="col-lg-6">
                                <?php echo e(Form::text('title', Input::old('title'), array('class' => 'form-control m-input', 'placeholder' => 'Enter your market title', 'required' => 'required'))); ?>

                                <?php if($errors->has('title')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('description', 'Description', array('class' => 'col-lg-3 col-form-label'))); ?>


                            <div class="col-lg-6">
                                <?php echo e(Form::textarea('description', Input::old('description'), array('class' => 'form-control m-input', 'placeholder' => 'Enter your market description'))); ?>

                                <?php if($errors->has('description')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <?php echo e(Form::submit('Update Market!', array('class' => 'btn btn-success'))); ?>

                                <?php echo e(Form::reset('Reset!', array('class' => 'btn btn-secondary'))); ?>

                            </div>
                        </div>

                        <?php echo e(Form::close()); ?>

                        <!--end::Form-->

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>