<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">View Market</div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-2" style="padding-top: 16px">
                                Market Title:
                            </div>
                            <div class="col-lg-4">
                                <strong> <?php echo e($market->title); ?></strong>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-2" style="padding-top: 16px">
                                Description:
                            </div>
                            <div class="col-lg-4">
                                <strong><?php echo e($market->description); ?></strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="row">
                <div class="col-xl-12">
                    <div class="m-portlet m-portlet--mobile ">
                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo e($market->title); ?>

                                    </h3>
                                </div>
                            </div>
                        </div>
                        <div class="m-portlet__body">
                            <!--begin: Datatable -->
                            <div class="m-section">
                                <span class="m-section__sub">The list of all of your stocks: </span>
                                <div class="m-section__content">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Company</th>
                                            <th>Market</th>
                                            <th>Type</th>
                                            <th>Price</th>
                                            <th>Last Update</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach($market->stocks as $key => $stock): ?>
                                            <tr>
                                                <th scope="row"><?php echo e($stock->id); ?></th>
                                                <td><?php echo e($stock->company->title); ?></td>
                                                <td><?php echo e($stock->market->title); ?></td>
                                                <td><?php echo e($stock->type); ?></td>
                                                <td> <span class=" bg-info text-white pull-right"><?php echo e(number_format($stock->price)); ?> €</span></td>
                                                <td><?php echo e($stock->updated_at); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!--end: Datatable -->
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>