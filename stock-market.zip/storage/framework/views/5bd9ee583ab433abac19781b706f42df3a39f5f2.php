<?php $__env->startSection('content'); ?>
    <div class="container">

        <!--Begin::Companies-->
        <div class="row">
            <div class="col-xl-12">
                <div class="m-portlet m-portlet--mobile ">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-caption">
                            <div class="m-portlet__head-title">
                                <h3 class="m-portlet__head-text">
                                    List of your Companies
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="m-portlet__body">
                        <!--begin: Datatable -->
                        <div class="m-section">
                            <span class="m-section__sub">The list of all of your companies: </span>
                            <div class="m-section__content">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>title</th>
                                        <th>address</th>
                                        <th>Telephone</th>
                                        <th>Url</th>
                                        <th>actions
                                            <a class="btn m-btn--square  btn-success pull-right"
                                               href="<?php echo e(URL::to('companies/create')); ?>">New Company</a></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach($companies as $key => $company): ?>
                                        <tr>
                                            <th scope="row"><?php echo e($company->id); ?></th>
                                            <td><?php echo e($company->title); ?></td>
                                            <td><?php echo e($company->office_address); ?></td>
                                            <td><?php echo e($company->office_tele); ?></td>
                                            <td><?php echo e($company->web_url); ?></td>
                                            <td>
                                                <?php echo e(Form::open(array('url' => 'companies/' . $company->id, 'class' => 'pull-right'))); ?>

                                                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                                <?php echo e(Form::submit('Delete', array('class' => 'btn m-btn--square  btn-danger',
                                                                         'onclick' => "return confirm('Are you sure you want to remove?')"))); ?>

                                                <?php echo e(Form::close()); ?>


                                                <a class="btn m-btn--square  btn-info"
                                                   href="<?php echo e(URL::to('companies/' . $company->id)); ?>">View</a>
                                                <a class="btn m-btn--square  btn-info"
                                                   href="<?php echo e(URL::to('companies/' . $company->id . '/edit')); ?>">Edit</a>

                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!--end: Datatable -->
                    </div>
                </div>
            </div>
        </div>
        <!--End::Companies -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>