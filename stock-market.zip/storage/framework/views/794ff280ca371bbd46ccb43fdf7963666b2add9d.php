<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    You are logged in!
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <?php foreach($markets as $key=> $market): ?>

            <?php $stock = $market->stocks->find($market->stocksHighest()["id"]) ?>

            <?php if($stock): ?>
                <div class="col-lg-4">
                    <?php if($stock["type"] === 'PREFERRED'): ?>
                        <div class="panel panel-primary">
                    <?php elseif($stock["type"] === 'COMMON'): ?>
                        <div class="panel panel-danger">
                    <?php else: ?>
                        <div class="panel panel-info">
                    <?php endif; ?>

                        <div class="panel-heading">
                            <h4><?php echo e($stock["company"]["title"]); ?></h4>
                            <h4><?php echo e($stock["type"]); ?></h4>
                            <h4><?php echo e(number_format($stock["price"])); ?> €</h4>

                        </div>
                        <div class="panel-body">
                                <div class="row" style="padding: 8px">
                                    <div class="col-8 col-sm-8">
                                        <?php echo e($market->title); ?>

                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>