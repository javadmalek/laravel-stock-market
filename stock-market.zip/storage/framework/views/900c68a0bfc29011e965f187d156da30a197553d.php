<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">View Stock</div>
                    <div class="panel-body">
                        <div class="form-group">
                            <div class="col-lg-6" style="padding-top: 16px">
                                Company: <strong> <?php echo e($stock->company->title); ?></strong>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-6" style="padding-top: 16px">
                                Market: <strong> <?php echo e($stock->market->title); ?></strong>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-6" style="padding-top: 16px">
                                Type: <strong> <?php echo e($stock->type); ?></strong>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-6" style="padding-top: 16px">
                                Price: <strong> <?php echo e(number_format($stock->price)); ?></strong>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-lg-6" style="padding-top: 16px">
                                Description: <strong><?php echo e($stock->description); ?></strong>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>